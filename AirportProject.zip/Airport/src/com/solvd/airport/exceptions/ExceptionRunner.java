package com.solvd.airport.exceptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.solvd.airport.Airport;
import com.solvd.airport.employees.Pilot;
import com.solvd.airport.employees.PlaneStaff;
import com.solvd.airport.planes.Jet;

public class ExceptionRunner {

	public final static void main(String args[]) throws Exception {
		
		// Logger
		Logger logger = Logger.getLogger("MyLogger");
		FileHandler fh = new FileHandler("MyLogFile.log");
		logger.addHandler(fh);

		// Exception 1: PilotNotExceperiencedException
		try {
			if(Pilot.getdOB() > 2005) {
				throw new PilotNotExperiencedException("The pilot is too young to fly");
			}
		} catch (PilotNotExperiencedException ex) {
			System.out.println("There was an error: " + ex.getMessage());
			logger.info(ex.getMessage());
		}
		finally {
			System.out.println("[Exception 1 Finally Block]");
		}
		

		// Exception 2: DOBNotEnteredProperlyException
		   int n = Pilot.getdOB();
		   try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		   {
		        n = Integer.parseInt(br.readLine());
		        throw new Exception();
		   }
		   catch (DOBNotEnteredProperlyException ex) {
				System.out.println("There was an error: " + ex.getMessage());
				logger.info(ex.getMessage());
		   }
		   
		
	
	
		// Exception 3: AirportNameNotFound
		String destination = Airport.getName();
		try {
			if(destination == null) {
				throw new AirportNameNotFoundException("Destination Not Found");
			} 
		} catch (AirportNameNotFoundException ex) {
			System.out.println("There was an error: "+ ex.getMessage());
			logger.info(ex.getMessage());
		} finally 
		{
			System.out.println("[Exception 3 Finally Block]");
		}

		// Exception 4: NotEnoughStaffException
		int staffCount = PlaneStaff.getPlaneStaffNumber();
		int minStaff = 20;
		try {
			if(staffCount < minStaff) {
				throw new NotEnoughStaffException("Not enough staff working on the flight");
			} 
		} catch (NotEnoughStaffException ex) {
			System.out.println("There was an error: "+ ex.getMessage());
			logger.info(ex.getMessage());
		} finally {
			System.out.println("[Exception 4 Finally Block]");
		}


		// Exception 5: JetGunsNotFound
		String guns = Jet.getGuns();
		try {
			if(guns == null) {
				throw new JetGunsNotFound("Jet Guns Not Found");
			}
		} catch (JetGunsNotFound ex) {
			System.out.println("[JetNotFound] "+ ex.toString());
			logger.info(ex.getMessage());
		} finally {
			System.out.println("[Exception 4 Finally Block]");
			logger.log(Level.ALL,"Exception 5 Finally");
		}

		
	}
}

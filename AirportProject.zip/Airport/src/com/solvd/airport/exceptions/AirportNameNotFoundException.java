package com.solvd.airport.exceptions;

public class AirportNameNotFoundException extends Exception {
	public AirportNameNotFoundException(String ex) {
		super(ex);
	}
}
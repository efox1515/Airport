package com.solvd.airport.exceptions;

public class JetGunsNotFound extends Exception {
	public JetGunsNotFound(String ex) {
		super(ex);
	}
}
package com.solvd.airport.Lambdas;

public interface LambdaGenericInterfaceStringMultiplied<T> {
	T GetMultipliedString(T str, int times);
}
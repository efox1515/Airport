package com.solvd.airport.enums;

public enum PhoneModel {
	
	IPHONE,
    ANDROID,
    WINDOWS;
    
    public static boolean isIPhone(String phoneModelName) {
        return phoneModelName.equalsIgnoreCase("iPhone");
    }
    
    public static boolean isAndroid(String phoneModelName) {
        return phoneModelName.equalsIgnoreCase("Android");
    }
    
    public static boolean isWindows(String phoneModelName) {
        return phoneModelName.equalsIgnoreCase("Windows");
    }
}

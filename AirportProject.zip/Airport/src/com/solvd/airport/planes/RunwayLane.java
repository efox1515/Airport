package com.solvd.airport.planes;

public class RunwayLane {
	
	private int runwaylane;

	public int getRunwaylane() {
		return runwaylane;
	}

	public void setRunwaylane(int runwaylane) {
		this.runwaylane = runwaylane;
	} 

}

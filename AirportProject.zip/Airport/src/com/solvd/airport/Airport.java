package com.solvd.airport;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class Airport {
	private static String name;

	public Airport() {
	}
	public  Airport(String name) {
		this.name = "JFK";
	}
	
	@Override
	public String toString() {
		return this.name + ".";
	}
	
	@Override
	public boolean equals (Object obj)
	{
		if (this == obj)
		{
			return true; 
		}
		if (obj == null || obj.getClass()!=this.getClass())
		{
			return true; 
		}
		Airport a = (Airport) obj; 
		return a.getName().equals(this.name);
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.name);
	}
	
	
	public static String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	} 
	
	
	public static void main (String[] args) {
		
		HashMap<String, String> airportByCity = new HashMap<>();
		
		airportByCity.put("New York", "JFK");
		airportByCity.put("Los Angeles", "Lax");

	List<Airport> streams_airports = 
	Arrays.asList
	(new Airport("LAX"), new Airport("LGA"), new Airport("JFK"));
	
	// Non-terminal Operations
	List<String> streams_airportNames = streams_airports.stream().map(x -> x.getName()).collect(Collectors.toList());
	System.out.println("Map: "+streams_airportNames);

	List<String> streams_airportNamesFiltered = streams_airportNames.stream().filter(s->s.startsWith("U")).collect(Collectors.toList());
	System.out.println("Filter by startsWith U: "+streams_airportNamesFiltered);

	List<String> streams_airportNamesSorted = streams_airportNames.stream().sorted().collect(Collectors.toList());
	System.out.println("Sorted: "+streams_airportNamesSorted);

	List<String> streams_airportNamesDistinct = streams_airportNames.stream().distinct().collect(Collectors.toList());
	System.out.println("Distinct: "+streams_airportNamesDistinct);

	// Terminal Operations
	System.out.print("ForEach: ");
	streams_airports.stream().map(x->x.getName()).forEach(y->System.out.print(y+" - "));
	System.out.println();

	String streams_airportNamesReduced = streams_airportNames.stream().reduce("",(ans,i)-> ans+" "+i+" -");
	System.out.println("Reduce: "+streams_airportNamesReduced);

	Set<String> streams_airportNamesSet = streams_airportNames.stream().map(x->x).collect(Collectors.toSet());
	System.out.println("Collect: "+streams_airportNamesSet);


	}

}

package com.solvd.airport;

import java.util.PriorityQueue;

public class SecurityGate {
	
	private int securityGate;

	public int getSecurityGate() {
		return securityGate;
	}

	public void setSecurityGate(int securityGate) {
		this.securityGate = securityGate;
	}

	
	public static void main (String[] args) {
		
		PriorityQueue<Integer> queue = new PriorityQueue<>();
		
		queue.offer(7);
		queue.offer(8);
		queue.offer(10);
		queue.offer(9);
		
	}

}

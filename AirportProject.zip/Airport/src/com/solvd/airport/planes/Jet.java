package com.solvd.airport.planes;

public class Jet {
	
	public int maxSpeed; 
	public static String guns;
	public int getMaxSpeed() {
		return maxSpeed;
	}
	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}
	public static String getGuns() {
		return guns;
	}
	public void setGuns(String guns) {
		this.guns = guns;
	} 

	public static void main(String[] args)
	{}
	

}
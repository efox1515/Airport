package com.solvd.airport.enums;

public enum DaysOfTheWeek {
	
	SUNDAY("Sunday"),
	MONDAY("Monday"),
	TUESDAY("Tuesday"),
	WEDNESDAY("Wednesday"),
	THURSDAY("Thursday"),
	FRIDAY("Friday"),
	SATURDAY("Saturday");

	private String daysGreeting;


	DaysOfTheWeek(final String daysGreeting) {
		this.daysGreeting = daysGreeting;
	}

	public String getDaysGreeting() {
		return daysGreeting;
	}

}




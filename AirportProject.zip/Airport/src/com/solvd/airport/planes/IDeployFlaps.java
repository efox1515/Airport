package com.solvd.airport.planes;

public interface IDeployFlaps {
	
	public default void deployFlaps() {
		System.out.println("Flaps deployed");
	}

}

package com.solvd.airport.planes;

public interface Ifly {

	public default void fly() {
		System.out.println("Flying");
	}
}

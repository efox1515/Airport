package com.solvd.airport.passenger;
import java.util.ArrayList;

public class Drink {
	
	private String drink;
	

	public String getDrink() {
		return drink;
	}

	public void setDrink(String drink) {
		this.drink = drink;
	}

	public static void main (String[] args) {
		
		ArrayList<String> list = new ArrayList<>();
		
		list.add("Coke");
		list.add("Pepsi");
		list.add ("Water");

	}
}
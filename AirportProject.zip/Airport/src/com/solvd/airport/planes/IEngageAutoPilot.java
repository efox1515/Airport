package com.solvd.airport.planes;

public interface IEngageAutoPilot {
	
	public default void engageAutoPilot() {
		System.out.println("Autopilot engaged");
	}

}

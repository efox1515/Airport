package com.solvd.airport.linkedList;
import java.util.LinkedList;

public class customLinkedList<T> {
	public static void main (String[] args) {
     
	LinkedList<String> list = new LinkedList<String>();
	list.add("Monday");
	list.add("Saturday"); 
	list.add("Friday");
	System.out.println("String linked list length : "+list.size());

	} 
}

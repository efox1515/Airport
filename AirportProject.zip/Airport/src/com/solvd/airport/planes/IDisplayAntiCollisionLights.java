package com.solvd.airport.planes;

public interface IDisplayAntiCollisionLights {

	public default void displayAntiCollisionLights() {
		System.out.println("Anti Collision Lights: ON");
	}
}

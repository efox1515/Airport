package com.solvd.airport.planes;

public class cruisingAlt {
	
	private int cruisingAlt;

	public int getCruisingAlt() {
		return cruisingAlt;
	}

	public void setCruisingAlt(int cruisingAlt) {
		this.cruisingAlt = cruisingAlt;
	} 

}

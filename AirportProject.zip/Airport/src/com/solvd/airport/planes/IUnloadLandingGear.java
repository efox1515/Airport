package com.solvd.airport.planes;

public interface IUnloadLandingGear {
	
	public default void unloadLandingGear() {
		System.out.println("Landing gear unloading");
	}

}

package com.solvd.airport.exceptions;

public class PilotNotExperiencedException extends Exception {
	public PilotNotExperiencedException(String ex) {
		super(ex);
	}
}
package com.solvd.airport.Lambdas;

public interface LambdaGenericInterfaceStringDoubled<T> {
	T GetDoubledString(T str);
}

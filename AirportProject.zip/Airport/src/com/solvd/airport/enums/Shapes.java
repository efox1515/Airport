package com.solvd.airport.enums;

public enum Shapes {
	   CIRCLE,
	   TRIANGLE,
	   SQUARE;
	   
		
	   public double getArea() {
	      if (this == CIRCLE) 
	      {
	    	 double radius = 0;
	         return Math.PI * Math.pow(radius,2.0);
	      } 
	      else if (this == TRIANGLE) 
	      {
	    	  double height = 0;
	    	  double base = 0;
	         return 0.5 * base * height;
	      }
	      else
	      {
	    	 double side = 0;
	         return Math.pow(side,2.0);
	      }
	   }
}
	  



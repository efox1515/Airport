package com.solvd.airport.exceptions;

public  class DOBNotEnteredProperlyException extends Exception {
	public DOBNotEnteredProperlyException(String ex) {
		super(ex);
	}
}
